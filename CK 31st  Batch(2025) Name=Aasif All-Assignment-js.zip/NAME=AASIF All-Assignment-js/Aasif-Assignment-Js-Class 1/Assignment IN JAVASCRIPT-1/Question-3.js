let a = 10;
let b = 5;
let c = a + b;
console.log("Total number is:", c);