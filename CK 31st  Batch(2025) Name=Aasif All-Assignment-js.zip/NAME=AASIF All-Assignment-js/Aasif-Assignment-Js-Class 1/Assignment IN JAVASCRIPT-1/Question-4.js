let A = 10;
let B = 5;

let sum = A + B;
let difference = A - B;
let product = A * B;
let quotient = A / B;
let remainder = A % B;

console.log("Sum:", sum);
console.log("Difference:", difference);
console.log("Product:", product);
console.log("Quotient:", quotient);
console.log("Remainder:", remainder);
