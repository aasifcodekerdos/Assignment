// console.log("question-1")

function Table(number) {
    for (i = 1; i <= 10; i++) {
        console.log(`${number} * ${i} = ${number * i}`);
    }
}

Table(2);