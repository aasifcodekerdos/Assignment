function revereStr(str) {
    let revered = "";

    for (i = str.lenght - 1; i >= 0; i--){
        revered += str[i];
    }
}

return revered;

let input = "Aasif";
let output = revereStr(input);
console.log(output);

// function reverseString(str) {
//     let reversed = "";
//     for (let i = str.length - 1; i >= 0; i--) {
//         reversed += str[i];
//     }
//     return reversed;
// }


// let input = "Aasif";
// let output = reverseString(input);
// console.log(output); 
