function sumOfDigits(input) {
    
    if (isNaN(input) || typeof input === "string" && input.trim() === "") {
        return "Not a valid input";
    }

   
    let str = Math.abs(parseInt(input)).toString(); 
    let sum = 0;
    for (let i = 0; i < str.length; i++) {
        sum += parseInt(str[i]);
    }
    return sum;
}


console.log(sumOfDigits(123));     
console.log(sumOfDigits("Rohan")); 
