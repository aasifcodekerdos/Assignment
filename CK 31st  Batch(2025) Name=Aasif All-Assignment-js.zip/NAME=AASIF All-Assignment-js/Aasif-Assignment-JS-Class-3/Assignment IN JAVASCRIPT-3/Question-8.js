function getMultiples(num) {

    if (isNaN(num) || num === 0) {
        return "Please provide a valid non-zero number";
    }

    let multiples = [];
    for (let i = 1; i <= 5; i++) {
        multiples.push(num * i);
    }
    return multiples;
}


console.log(getMultiples(3)); 
