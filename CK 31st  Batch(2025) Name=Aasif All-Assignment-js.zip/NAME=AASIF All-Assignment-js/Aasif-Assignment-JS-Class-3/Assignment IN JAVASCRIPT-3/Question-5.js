function countWords(str) {
   
    let words = str.trim().split(/\s+/);

    
    if (words[0] === "") {
        return 0;
    }

    return words.length;
}


console.log(countWords("Rohan"));              
console.log(countWords("JavaScript is fun"));  
