// console.log('question-6');

function printPosition(S, N)
{
    if (N >= 0 && N < S.length)
    {
        console.log(S[N]);
    }
    else
    {
        console.log("Out of range");
    }
}


printPosition("Developer", 6); 
printPosition("Aasif", 8);    
  