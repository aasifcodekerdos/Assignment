console.log("question-1");

function sum(number) {
   
    const digits = Math.abs(number).toString();

    
    let sum = 0;
    for (let digit of digits) {
        sum += parseInt(digit, 10);
    }

    return sum;
}


const input = 343;
console.log(`Sum of digits of ${input} is: ${sum(input)}`);