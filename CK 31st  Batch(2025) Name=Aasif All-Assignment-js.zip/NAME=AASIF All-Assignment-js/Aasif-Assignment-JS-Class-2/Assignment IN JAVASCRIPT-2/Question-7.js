// console.log('question-7');

function convertToUpperCase(str)
{
    const upperStr = str.toUpperCase();
    console.log(upperStr);
}


convertToUpperCase("Hello developers"); 
  