// console.log('Question-18')


function check(str) {
    if (str.length === 0) {
        console.log("empty");
    } else {
        console.log("not empty");
    }
}


check("");       
check("Aasif"); 
