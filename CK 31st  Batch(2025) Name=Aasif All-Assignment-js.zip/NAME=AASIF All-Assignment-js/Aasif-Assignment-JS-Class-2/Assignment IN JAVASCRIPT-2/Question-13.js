// console.log('question-13')


function checkWord(str, word) {
    
    if (str.toLowerCase().includes(word.toLowerCase())) {
        console.log("Yes");
    } else {
        console.log("No");
    }
}


let str = "Delhi is the capital of India";
let word = "capital";

checkWord(str, word); 
