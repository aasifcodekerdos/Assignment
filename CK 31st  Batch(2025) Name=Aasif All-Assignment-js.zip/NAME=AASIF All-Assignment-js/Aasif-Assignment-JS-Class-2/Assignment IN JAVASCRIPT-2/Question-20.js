// console.log('question-20')

function findLargest(A, B, C) {
    let largest = A;

    if (B > largest) {
        largest = B;
    }

    if (C > largest) {
        largest = C;
    }

    console.log(largest + " is the largest");
}


findLargest(9, 3, 56); 
