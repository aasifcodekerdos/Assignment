console.log("Question-3");

function arithmeticOperations(a, b)
{
    console.log(`Addition: ${a + b}`);
    console.log(`Subtraction: ${a - b}`);
    console.log(`Multiplication: ${a * b}`);
    console.log(`Division: ${a / b}`);
    console.log(`Modulus: ${a % b}`);
}

// Sample input
const A = 13;
const B = 2;

arithmeticOperations(A, B);
  