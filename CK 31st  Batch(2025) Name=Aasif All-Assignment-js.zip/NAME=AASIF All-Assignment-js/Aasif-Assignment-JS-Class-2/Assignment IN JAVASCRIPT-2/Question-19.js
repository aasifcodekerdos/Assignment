// console.log('question-19')


function getGrade(marks) {
    if (marks >= 90 && marks <= 100) {
        console.log("A");
    } else if (marks >= 80 && marks < 90) {
        console.log("B");
    } else if (marks >= 70 && marks < 80) {
        console.log("C");
    } else if (marks >= 60 && marks < 70) {
        console.log("D");
    } else if (marks >= 50 && marks < 60) {
        console.log("E");
    } else if (marks < 50 && marks >= 0) {
        console.log("F");
    } else {
        console.log("Invalid marks");
    }
}


getGrade(85); 
getGrade(92); 
