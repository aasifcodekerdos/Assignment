// console.log('question-14')

function endsWithWord(str, word) {
    
    return str.toLowerCase().endsWith(word.toLowerCase());
}


let str = "Hello my friends";
let word = "friends";

console.log(endsWithWord(str, word));
