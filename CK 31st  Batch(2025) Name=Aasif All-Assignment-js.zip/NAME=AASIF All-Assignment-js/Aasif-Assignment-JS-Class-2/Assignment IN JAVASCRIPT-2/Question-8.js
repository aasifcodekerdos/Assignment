// console.log('question-8')

function removeWhitespaces(str) {
    const trimmedStr = str.trim();
    console.log(`"${trimmedStr}"`);
}


removeWhitespaces("  Aasif  ");         
removeWhitespaces("  Atma Nirbhar  ");  
  
