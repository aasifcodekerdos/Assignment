// console.log("question-10")

function printFirstWord(sentence)
{
    const words = sentence.trim().split(" ");
    console.log(words[0]);
}


printFirstWord("Javascript is fun"); 
printFirstWord("develop");           
  