// console.log("question-9")

function extractSubstring(str, start, length)
{
    const substring = str.substr(start, length);
    console.log(`"${substring}"`);
}


const sentence = "Aasif is an engineer from Odisha";


extractSubstring(sentence, 11, 8); 
  