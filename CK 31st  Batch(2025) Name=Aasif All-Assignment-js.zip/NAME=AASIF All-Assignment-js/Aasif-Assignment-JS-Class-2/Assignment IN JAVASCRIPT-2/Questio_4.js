console.log("question_4");

function roundToTwoDecimals(number) {
    const rounded = number.toFixed(2);
    console.log(rounded);
}


roundToTwoDecimals(3.12564); 
roundToTwoDecimals(3.1234564);
roundToTwoDecimals(9.1111);

  