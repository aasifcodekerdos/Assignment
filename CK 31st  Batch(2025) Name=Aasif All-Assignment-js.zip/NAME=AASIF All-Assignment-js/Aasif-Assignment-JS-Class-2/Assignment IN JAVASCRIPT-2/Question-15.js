// console.log('question-15')


function find(str, character) {
   
    let index = str.toLowerCase().indexOf(character.toLowerCase());

    
    if (index !== -1) {
        console.log(index + 1);
    } else {
        console.log("Character not found");
    }
}


let str = "Apple";
let character = "p";

find(str, character); 
