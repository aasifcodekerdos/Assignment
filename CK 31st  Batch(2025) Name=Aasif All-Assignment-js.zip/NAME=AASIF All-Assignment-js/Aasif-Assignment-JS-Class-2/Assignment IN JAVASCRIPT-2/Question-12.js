// console.log('question')

function aasif(sentence) {
    
    let wordsArray = sentence.split(" ");
    return wordsArray;
}


let input1 = "My name is Aasif";
let input2 = "Brother";

console.log(aasif(input1)); 
console.log(aasif(input2)); 
