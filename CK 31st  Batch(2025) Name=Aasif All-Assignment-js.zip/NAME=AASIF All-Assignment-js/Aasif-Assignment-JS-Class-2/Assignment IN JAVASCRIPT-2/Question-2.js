console.log("question-2");


function convertStringToNumber(input) {
    
    input = input.trim();

    
    if (input === '' || isNaN(input)) {
        return "Characters are not allowed";
    }

    
    return Number(input);
}


console.log(convertStringToNumber("123"));
console.log(convertStringToNumber("Sample input 1:a"));  
console.log(convertStringToNumber(" 456 ")); 
console.log(convertStringToNumber("12abc")); 
  


