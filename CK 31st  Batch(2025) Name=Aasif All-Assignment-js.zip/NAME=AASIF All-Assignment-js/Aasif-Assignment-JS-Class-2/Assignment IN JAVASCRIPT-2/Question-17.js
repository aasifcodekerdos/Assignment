// console.log('question-17')

function checkPosit(number) {
    if (number >= 0) {
        console.log("positive");
    } else {
        console.log("negative");
    }
}


checkPosit(7);  
checkPosit(-1); 
