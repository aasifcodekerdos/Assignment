// console.log('Question')

function replace(S1, S2, S3) {
    
    let regex = new RegExp(S2, 'i');

   
    let replaced = S1.replace(regex, S3);

    
    let finalResult = replaced.charAt(0).toUpperCase() + replaced.slice(1);

    return finalResult;
}


let output1 = replace("Bad guy is here", "bad", "good");
let output2 = replace("Designer is signed", "sign", "fry");

console.log(output1); 
console.log(output2); 
