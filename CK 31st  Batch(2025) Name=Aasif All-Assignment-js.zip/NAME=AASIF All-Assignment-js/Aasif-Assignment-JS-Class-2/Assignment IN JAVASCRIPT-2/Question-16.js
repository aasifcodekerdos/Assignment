// console.log('question-16')


function checkEvenOrOdd(number) {
    if (number % 2 === 0) {
        console.log("Even");
    } else {
        console.log("Odd");
    }
}


checkEvenOrOdd(7); 
checkEvenOrOdd(4); 
