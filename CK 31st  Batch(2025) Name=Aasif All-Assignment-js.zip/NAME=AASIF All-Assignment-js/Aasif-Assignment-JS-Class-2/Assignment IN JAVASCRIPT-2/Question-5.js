console.log("question-5");


function print(str)
{
    console.log(str.length);
}


print("Javascript");
  