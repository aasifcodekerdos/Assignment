// console.log('question-2');

let str = "Hello";
let num = 42;
let bool = true;
let empty = null;
let notDefined;
let sym = Symbol("id");

console.log(typeof (str));
console.log(typeof (num));
console.log(typeof (bool));
console.log(typeof (notDefined));
console.log(typeof (sym));

//type or
console.log(str, "→", typeof str);
console.log(num, "→", typeof num);
console.log(bool, "→", typeof bool);
console.log(empty, "→", typeof empty);
console.log(notDefined, "→", typeof notDefined);
console.log(sym.toString(), "→", typeof sym);