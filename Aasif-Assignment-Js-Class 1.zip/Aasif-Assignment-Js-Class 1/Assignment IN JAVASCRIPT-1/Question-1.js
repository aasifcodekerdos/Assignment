// console.log('question-1');
console.log('WELCOME TO JAVASCRIPT')