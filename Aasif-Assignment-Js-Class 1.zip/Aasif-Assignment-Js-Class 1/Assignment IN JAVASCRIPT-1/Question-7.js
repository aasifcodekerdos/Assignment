    // let X = 5,
    // let Y = 12,
// let Z = 43
    

let a = 5;
let b = 12;
let c = 43;

let avg = (a + b + c) / 3;
console.log("Average:", avg);