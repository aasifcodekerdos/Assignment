if (true) {
    var a = 5;
    let b = 10;
}

console.log("a:", a);
console.log("b:", b);  //Note=>ReferenceError: b is not defined
