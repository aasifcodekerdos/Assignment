const birthYear = 2001;
console.log(birthYear);

birthYear = 2012;
console.log(birthYear);


//Output => 2001
//TypeError: Assignment to constant variable.
