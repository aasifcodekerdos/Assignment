
let principal = 10000;
let rate = 5;
let time = 5;

let simpleInterest = (principal * rate * time) / 100;

console.log("Simple Interest:", simpleInterest);
